<?php $__env->startSection('title', 'profile'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">  
        <div class="profile">
            <div class="profile-head">
                <div class="profile-head-img">
                    <img src="<?php echo e(asset('images/'. $user->profile->avarta)); ?>">
                </div>
                <div class="profile-head-info">
                    <div class="head-info-name">
                        <h1><?php echo e($user->name); ?></h1>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-profile', $user->profile)): ?>
                        <a href="<?php echo e(route('profile.edit', $user->slug)); ?>">Edit Profile</a>
                        <?php endif; ?>
                        
                    </div>
                    
                    <div class="profile-head-statistic">
                        <span><?php echo e(count($user->posts)); ?> bài viết</span>
                        <span>200 bình luận</span>
                        <span>4000 lượt xem</span>
                    </div>
                    <div class="profile-head-social">
                        <a target="break" href="<?php echo e($user->profile->fbsocial); ?>" id="fb">
                            Facebook
                        </a>
                        <a href="<?php echo e($user->profile->linkedInsocial); ?>" id="linked">
                            Linkedin
                        </a>
                    </div>
                </div>
            </div>

            <div class="profile-posts">
                <div class="row">
                    <div class="col-md-2"></div> 
                    <div class="col-md-8">
                    <div class="blogs">
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <a class="nav-link active" id="published-tab" data-bs-toggle="tab" href="#published" role="tab" aria-controls="home" aria-selected="true">Đã đăng (<?php echo e(count($postsPublished)); ?>)</a>
                            </li>
                            <?php if(Auth::id() === $user->id  ): ?>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link " id="unpublish-tab" data-bs-toggle="tab" href="#unpublish" role="tab" aria-controls="profile" aria-selected="false">Chưa đăng (<?php echo e(count($postsUnpublish)); ?>)</a>
                            </li>
                            <?php endif; ?>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="published" role="tabpanel" aria-labelledby="published-tab">
                                <?php $__currentLoopData = $postsPublished; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="blog blogInProfile">
                                    <a href="<?php echo e(route('profile.index', $post->user->slug)); ?>" class="blog-img"><img src="<?php echo e(asset('images/'. $post->user->profile->avarta)); ?>" alt=""></a>
                                    <div class="blog-body">
                                        <a href="<?php echo e(route('post.show',$post->slug)); ?>" class="blog-title"><?php echo e($post->title); ?></a>
                                        <div class="blog-categories">
                                            <?php $__currentLoopData = $post->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e(route('category.show', $category->slug)); ?>" id="blog-category"><?php echo e($category->name); ?></a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <div class="author-delete-edit">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $post)): ?>
                                            <a href="<?php echo e(route('post.edit', $post->slug)); ?>">Chỉnh sửa bài viết</a>
                                            <a href="<?php echo e(route('post.destroy', $post->id)); ?>">Xóa bài viết</a>
                                            <?php endif; ?>
                                            <a href="<?php echo e(route('post.unpublish', $post->id)); ?>" class="publishbtn">Unpuslish</a>
                                            
                                        </div>
                                        <!-- <div><?php echo substr($post->content,0, 150); ?> ...</div> -->
                                        <div class="blog-other">
                                        <a href="<?php echo e(route('profile.index', $post->user->slug )); ?>">  <?php echo e($post->user->name); ?> </a> đăng <?php echo e($post->getCreated_atAttribute()); ?>

                                        </div>
                                    </div>
                                    <div class="blog-count-comment">
                                        <?php echo e(count($post->comment)); ?>

                                        <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chat-left-dots" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" d="M14 1H2a1 1 0 0 0-1 1v11.586l2-2A2 2 0 0 1 4.414 11H14a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1zM2 0a2 2 0 0 0-2 2v12.793a.5.5 0 0 0 .854.353l2.853-2.853A1 1 0 0 1 4.414 12H14a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z"/>
                                        <path d="M5 6a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm4 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm4 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
                                        </svg>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <?php if(Auth::id() === $user->id  ): ?>
                            <div class="tab-pane fade show " id="unpublish" role="tabpanel" aria-labelledby="unpublish-tab">
                                <?php $__currentLoopData = $postsUnpublish; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="blog blogInProfile">
                                    <a href="<?php echo e(route('profile.index', $post->user->slug)); ?>" class="blog-img"><img src="<?php echo e(asset('images/'. $post->user->profile->avarta)); ?>" alt=""></a>
                                    <div class="blog-body">
                                    
                                        <a href="<?php echo e(route('post.show',$post->slug)); ?>" class="blog-title"><?php echo e($post->title); ?></a>
                                        <div class="blog-categories">
                                            <?php $__currentLoopData = $post->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e(route('category.show', $category->slug)); ?>" id="blog-category"><?php echo e($category->name); ?></a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <div class="author-delete-edit">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $post)): ?>
                                            <a href="<?php echo e(route('post.edit', $post->slug)); ?>">Chỉnh sửa bài viết</a>
                                            <a href="<?php echo e(route('post.destroy', $post->id)); ?>">Xóa bài viết</a>
                                            <?php endif; ?>
                                            <button type="button" data-post="<?php echo e($post->id); ?>" class="btn btn-primary publishnow" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                                Publish
                                            </button>
                                        </div>
                                        <!-- <div><?php echo substr($post->content,0, 150); ?> ...</div> -->
                                        <div class="blog-other">
                                        <a href="<?php echo e(route('profile.index', $post->user->slug )); ?>">  <?php echo e($post->user->name); ?> </a> đăng <?php echo e($post->getCreated_atAttribute()); ?>

                                        </div>
                                    </div>
                                    <div class="blog-count-comment">
                                        <?php echo e(count($post->comment)); ?>

                                        <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chat-left-dots" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" d="M14 1H2a1 1 0 0 0-1 1v11.586l2-2A2 2 0 0 1 4.414 11H14a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1zM2 0a2 2 0 0 0-2 2v12.793a.5.5 0 0 0 .854.353l2.853-2.853A1 1 0 0 1 4.414 12H14a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z"/>
                                        <path d="M5 6a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm4 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm4 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
                                        </svg>
                                    </div>
                                </div>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="modal fade" id="exampleModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        
                                        <a href="" id="parameterPost">Publish now</a>
                                        <div class="setPublish">
                                            <form action="<?php echo e(route('post.update.timepost', 1)); ?>" method="get" data-id="" class="posttime">
                                                <?php echo csrf_field(); ?>
                                                <label>Publish theo thời gian</label>
                                                <input type="datetime-local" name="timePost">
                                                <input type="submit" value="Lưu">
                                            </form>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="button" class="btn btn-primary">Save changes</button>
                                    </div>
                                </div>
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            
                        </div>
                    </div>
                    </div>
                    <div class="col-md-2"></div>  
                </div>
            </div>
        </div>
        <script>
            $(document).ready(function(){
                $(".publishnow").click(function(){
                    let id = $(this).attr('data-post');

                    let route = "<?php echo e(route('post.publish',3)); ?>";
                    let url = route.replace('3',id);
                    $('#parameterPost').attr('href',url);

                    let route_time = "<?php echo e(route('post.update.timepost', 1)); ?>";
                    let url_time = route_time.replace('1', id);
                    $(".posttime").attr('action', url_time);
                })
            })
        </script>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>