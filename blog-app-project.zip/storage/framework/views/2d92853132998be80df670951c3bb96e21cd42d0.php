<?php $__env->startSection('content'); ?>
<div class="container background">
    <div class="row">
        <div class="col-md-8 layout-main">
            <?php echo $__env->yieldContent('content-master'); ?>
        </div>
        <div class="col-md-4 layout-sidebar">
            <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>