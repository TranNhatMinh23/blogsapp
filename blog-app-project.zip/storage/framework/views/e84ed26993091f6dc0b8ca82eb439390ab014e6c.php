<?php $__env->startSection('title', 'Bài viết'); ?>

<?php $__env->startSection('content-master'); ?>
    <div class="container background-post">
        <div class="detailPost"> 
            <div class="fix-left sticky-score">
                <a href="#"><img src="<?php echo e(asset('images/' . $post->user->profile->avarta)); ?>"></a>
                <button id="fix-left-up">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-caret-up-fill" viewBox="0 0 16 16">
                    <path d="M7.247 4.86l-4.796 5.481c-.566.647-.106 1.659.753 1.659h9.592a1 1 0 0 0 .753-1.659l-4.796-5.48a1 1 0 0 0-1.506 0z"/>
                    </svg>
                </button>
                <span data-id="<?php echo e($post->id); ?>"><?php echo e($post->point); ?></span>
                <button id="fix-left-down">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-caret-down-fill" viewBox="0 0 16 16">
                    <path d="M7.247 11.14L2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z"/>
                    </svg>
                </button>
            </div>
            <div class="content">
                <h1><?php echo e($post->title); ?></h1>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $post)): ?>
                    <a href="<?php echo e(route('post.edit', $post->slug)); ?>">Chỉnh sửa bài viết</a> || 
                    <a href="<?php echo e(route('post.destroy', $post->id)); ?>">Xóa bài viết</a>
                <?php endif; ?>
            
                <div class="detail-categories">
                <?php $__currentLoopData = $post->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('category.show', $category->slug)); ?>"><?php echo e($category->name); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>

                <div class="creator">
                    <a href="<?php echo e(route('profile.index', $post->user->slug)); ?>" class="creator-img">
                        <img src="<?php echo e(asset('images/' . $post->user->profile->avarta)); ?>">
                    </a>
                    <div class="creator-name">
                        <a href="<?php echo e(route('profile.index', $post->user->slug)); ?>"><?php echo e($post->user->name); ?></a>
                        đăng 3 giờ trước
                    </div>
                </div>
                
                <div id="contentString"><?php echo $post->content; ?></div>
            </div>
            
            <?php if(auth()->guard()->guest()): ?>
            Phải đăng nhập mới được bình luận
            <?php else: ?>
            <div class="comments">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <div class="articleComment">
                    <div class="img-formComment">
                    <img src="<?php echo e(asset('/images/' . Auth::user()->profile->avarta )); ?>">
                    </div>
                    <form id="formComment" action="<?php echo e(route('comment.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="text" value="" placeholder="comment.." name="content" class="inputComment" id="content">
                        <input type="hidden" value="" id="auth-info" auth-name="<?php echo e(Auth::user()->name); ?>" auth-avarta = "<?php echo e(Auth::user()->profile->avarta); ?>" >
                        <!-- <input type="submit" value="Bình luận"> -->
                    </form>
                </div>
                <div class="countComment"><?php echo e(count($comments)); ?> bình luận</div>
                <div class="listComment">
                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="comment">
                        <input type="hidden" value="<?php echo e($comment->id); ?>"id="idComment">
                        <a href="<?php echo e(route('profile.index', $comment->users->slug)); ?>" class="commentimg">
                        <img src="<?php echo e(asset('/images/' . $comment->users->profile->avarta )); ?>" alt="">
                        </a>
                        <div class="commentbody">
                            <div id="commentname">
                            <a href="<?php echo e(route('profile.index', $comment->users->slug)); ?>" id="name"><?php echo e($comment->users->name); ?></a>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $comment)): ?>
                            <a href="<?php echo e(route('comment.destroy',$comment->id)); ?>" id="commentdel" data-id="<?php echo e($comment->id); ?>">Xóa comment</a>
                            <?php endif; ?>
                            </div>
                            <p id="commentcontent"><?php echo e($comment->content); ?></p>
                        </div>
                        
                        <div id="commenttime">30 phút trước</div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>
    
        </div>
    </div>

    <script>
        function ajaxPoint($type) {
            let point = $(".fix-left span");
            let getId = point.attr('data-id');
            let urlUp = "<?php echo e(route('post.up.point',156723)); ?>";
            let urlDown = "<?php echo e(route('post.down.point',1222153)); ?>";
            let urlCurrentUp = urlUp.replace('156723', getId);
            let urlCurrentDown = urlDown.replace('1222153', getId);
            let urlCurrent = null;
            
            switch($type) {
                case 'up':
                    urlCurrent = urlCurrentUp;
                    break;
                case 'down':
                    urlCurrent = urlCurrentDown;
                    break;
                default:
                    break;
            }
            $.ajax({
                url: urlCurrent,
                type: "GET",
                success: function(data)
                {
                    // alert("Cảm ơn bạn đã đánh giá.")
                },
            })
        }
        function up_down($parameter, $flag) {
            let point = $(".fix-left span");
            let up = $("#fix-left-up");
            let down = $("#fix-left-down");
            if($flag) {
                up.attr('disabled', true);
                down.removeAttr('disabled', true);
                console.log('up');
            }
            else {
                down.attr('disabled', true);
                up.removeAttr('disabled', true);
                console.log('down');
            }
            console.log($flag);
            let calculate; 
            switch ($parameter) {
                case 1:
                    calculate = parseInt(point.text()) + 1;
                    break;
                case 2:
                    calculate = parseInt(point.text()) - 1;
                    break;
                default:
                    break;
            }
            point.text(calculate);           
        }
        function checkLogin() {
            let check = '<?php echo e(Auth::id()); ?>';
            if(check > 0) {
                return true;
            }
            else {
                let url = '<?php echo e(route("login")); ?>';
                $(location).attr('href',url);
                return false;
            }
        }
        var flag = true;
        $(document).on('click', '#fix-left-up', function() {
            var up = 1;
            flag = true;
            if(checkLogin()) {
                up_down(up, flag);
                ajaxPoint('up');
            }
        })
        $(document).on('click', '#fix-left-down', function() {
            flag = false;
            var down = 2;
            if(checkLogin()) {
                up_down(down, flag);
                ajaxPoint('down');
            }  
        })
    </script>
    <script>
        $(document).on('submit', '#formComment', function(e) {
            e.preventDefault();
            let image = $("#auth-info").attr('auth-avarta');
            let url_avarta = '<?php echo e(asset("/images/")); ?>'+ '/' + image;
            let name = $("#auth-info").attr('auth-name');
            let comment = $("#content").val();
            let user = '<?php echo e(Auth::id()); ?>';
            let post = '<?php echo e($post->id); ?>';
            let _token = $("input[name=_token]").val();
            $.ajax({
                url: "<?php echo e(route('comment.store')); ?>",
                type: "POST",
                data: {
                    content: comment,
                    post_id: post,
                    user_id: user,
                    _token : _token
                },
                success: function(data)
                {
                    let str = `
                    <div class="comment">
                        <input type="hidden" value="`+ data.id +`"id="idComment">
                        <a href="#" class="commentimg">
                        <img src="`+ url_avarta +`" alt="">
                        </a>
                        <div class="commentbody">
                            <div id="commentname">
                            <a href="#" id="name">`+ name +`</a>
                            <a href="" id="commentdel" data-id="`+ data.id +`">Xóa comment</a>
                            </div>
                            <p id="commentcontent">`+ data.content + `</p>
                        </div>
                        
                        <div id="commenttime">5 phút trước</div>
                    </div>
                    `;
                    $(".listComment").prepend(str);
                    $(".inputComment").val('');
                },
            })

        })        
    </script>

    <script>
    $(document).ready(function(){
        var width = $(".background").width();
    var screen = $("#app").width();
    var cal = ((screen - width) / 2) - 35;
    console.log('background: '+ width + " screen: " + screen)
    $(".fix-left").css("left", cal);
    })
    window.onscroll = function() {myFunction()};
    
    function myFunction() {
        var Offset = $(".header").offset().top -3;
        if(window.pageYOffset > Offset)
        {
            $(".sticky-score img").css("opacity", "1");
        }
        else {
            $(".sticky-score img").css("opacity", "0");
        }
    }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>