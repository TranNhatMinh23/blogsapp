<?php $__env->startSection('title', 'Edit bài viết'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <form method="POST" action="<?php echo e(route('post.update', $post->id)); ?>">
        <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="exampleFormControlInput1">Tiêu đề bài viết</label>
                <input name="title" value="<?php echo e($post->title); ?>" type="text" class="form-control" id="title-post" placeholder="Title content">
                <input type="hidden" value="<?php echo e($post->slug); ?>" name="slug" id="slug-post">
            </div>
            <input name="user_id" value="<?php echo e(Auth::id()); ?>" type="hidden" class="form-control" id="exampleFormControlInput1" placeholder="Title content" value="">
            <div class="form-group">
                <label for="">Chủ đề</label>
                <br>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="checkbox" id="<?php echo e($category->id); ?>" name="categorySelect[]" value="<?php echo e($category->id); ?>">
                <label for="<?php echo e($category->id); ?>"> <?php echo e($category->name); ?></label><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="form-group">
                <label for="exampleFormControlTextarea1">Nội dung</label>
                <textarea name="content" class="form-control my-editor" ><?php echo e($post->content); ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Cập nhật</button>
        </form>

        <script>
            $(document).ready(function() {            
                let title = $("#title-post");
                let slug = $("#slug-post")
                title.keyup(function(){
                    var textSlug = slugfnc(title.val());
                    slug.val(textSlug);
                });
            })
        </script>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>