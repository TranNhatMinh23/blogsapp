<?php $__env->startSection('title', 'Viết bài'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">     

        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        
        
        <form id="form-add-post" method="POST" action="<?php echo e(route('post.store')); ?>">
        <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="">Tiêu đề bài viết</label>
                <input name="title" type="text" class="form-control" id="title-post" placeholder="Tiêu đề bài viết">
            </div>
            <input name="slug" type="hidden" value="" id="slug-post">
            <input name="user_id" value="<?php echo e(Auth::id()); ?>" type="hidden" class="form-control">
            <div class="form-group">
                <label for="">Chủ đề</label>
                <br>
                <div class="categoriesform">
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="checkbox" class="select-category"  id="<?php echo e($category->id); ?>" name="categorySelect[]" value="<?php echo e($category->id); ?>">
                <label for="<?php echo e($category->id); ?>"> <?php echo e($category->name); ?></label><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <button type="button" class="add-category" data-toggle="modal" data-target="#exampleModal">
                    Thêm chủ đề
                </button>

            </div>
            <div class="form-group">
                <label for="exampleFormControlTextarea1">Nội dung</label>
                <textarea name="content" class="form-control my-editor" ></textarea>
            </div>
            <button type="submit" class="btn btn-primary" id="savePost">Lưu bài viết</button>
            <button type="submit" class="btn btn-primary" id="publishPost">Đăng bài viết</button>
        </form>
        
        
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <form action="<?php echo e(route('category.store')); ?>" class="form-category"  method="POST">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title " id="exampleModalLabel">Thêm chủ đề</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <?php echo csrf_field(); ?>
                        <input name="name" type="text" class="form-control" id="name-category">
                        <input name="slug" type="hidden" value="" id="slug-category">
                        
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <input type="submit" id="add-category" class="btn btn-primary" value="Submit">
                </div>
                </div>
            </form>
        </div>
        </div>

       <script type='text/javascript'>
        function TitleToSLug() {
            let title = $("#title-post");
            let slug = $("#slug-post");
            title.keyup(function(){
                let textSlug = slugfnc(title.val());
                slug.val(textSlug);
            });
        }

        function CategoryToSlug() {
            let name = $("#name-category");
            let slug = $("#slug-category");
            name.keyup(function(){
                let textSlug = slugfnc(name.val());
                slug.val(textSlug);
            })
        }

        function ajaxPost($isPost) {
            
            let arrCategory = [];
            tinyMCE.triggerSave();
            $('input[type=checkbox]:checked').map(function(_, el) {
                arrCategory.push($(el).val());
            }).get();
            let _token = $("input[name=_token]").val();
            let title = $("#title-post").val();
            let slug = $("#slug-post").val();
            let content = $(".my-editor").val();
            $.ajax({
                type : "POST",
                url: "<?php echo e(route('post.store')); ?>",
                data: {
                    _token : _token,
                    title: title,
                    slug: slug,
                    published: $isPost,
                    content: content,
                    user_id: '<?php echo e(Auth::id()); ?>',
                    categorySelect: arrCategory,
                },
                success: function(data) {
                    console.log(data);
                }
            })
        }

        $(document).on('click', '#savePost', function (e){
            e.preventDefault();
            $isPost = 0;
            ajaxPost($isPost);
        })
        $(document).on('click', '#publishPost', function (e){
            e.preventDefault();
            $isPost = 1;
            ajaxPost($isPost);
        })
        $(document).on('submit', '.form-category', function(e){
            e.preventDefault();
            let _token = $("input[name=_token]").val();
            
            $.ajax({
                type : "POST",
                cache: false,
                url: "<?php echo e(route('category.store')); ?>",
                data: {
                    _token : _token,
                    name: $("#name-category").val(),
                    slug: $("#slug-category").val()
                },
                success: function(data) {
                    let obj = data;
                    let str = `
                    <input type="checkbox" id="`+ data.id +`" name="categorySelect[]" value="`+ data.id +`">
                    <label for="`+ data.id +`">`+  data.name +`</label><br>
                    `;
                    $(".categoriesform").append(str);
                }
            })

        })
        $(document).ready(function() {            
            TitleToSLug();
            CategoryToSlug();
        })
       </script>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>