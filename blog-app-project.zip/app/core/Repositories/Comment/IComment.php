<?php

namespace App\Core\Repositories\Comment;

interface IComment {
    public function orderById();
}